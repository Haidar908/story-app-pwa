// src/scripts/config.js
const CONFIG = {
    // Ganti dengan URL Story API yang sebenarnya
    BASE_URL: 'https://story-api.dicoding.dev/v1', 

    // Kunci VAPID Publik untuk Push Notification (WAJIB DIGANTI dengan kunci dari API Anda)
    PUSH_NOTIFICATION_VAPID_PUBLIC_KEY: '<<GANTI DENGAN KUNCI VAPID PUBLIC ANDA>>', 
};

export default CONFIG;